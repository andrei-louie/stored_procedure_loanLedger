-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 22, 2020 at 02:51 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `memberloanledger`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `emptyLoanBalance` ()  NO SQL
BEGIN
  DROP TABLE IF EXISTS `loanbalance`;
       CREATE TABLE `loanbalance` (memberid int, transdate date, loan decimal(13,2),payment decimal(13,2),balance decimal(13,2));  DROP TABLE IF EXISTS `loanbalance`;
       CREATE TABLE `loanbalance` (memberid int, transdate date, loan decimal(13,2),payment decimal(13,2),balance decimal(13,2));
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getAllMember` ()  BEGIN
	SELECT l.memberid, a.membername FROM accounts a inner join loan l ON a.memberid = l.memberid GROUP BY memberid, membername;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getMemberLoanTransaction` ()  NO SQL
BEGIN
SELECT * FROM loanbalance;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getMembername` (IN `get_id` INT)  NO SQL
BEGIN
SELECT membername FROM `accounts` WHERE memberid=get_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `memberloanledger` (IN `my_memberid` INT, IN `my_fiscal_year` INT)  BEGIN  
	-- Declare loop constructs --
    DECLARE done INT DEFAULT FALSE; 
    
    -- Declare VARIABLES --
	DECLARE my_running_bal DECIMAL(13,2) DEFAULT 0.00;
    DECLARE my_trans_date DATE;
	DECLARE my_Amount DECIMAL(13,2);
	DECLARE my_dummy INT;
    
    -- Declare Cursor --
	DECLARE LoanRemaining_cursor CURSOR FOR 
    	SELECT transdate, amount, 0 dummy FROM loan WHERE memberid=my_memberid AND YEAR(transdate) = my_fiscal_year
        Union ALL
	 	SELECT transdate, (-1 * amount) Amount, 1 dummy FROM payment WHERE memberid=my_memberid AND YEAR(transdate) = my_fiscal_year ORDER BY transdate;
     
     -- Declare Continue Handler --
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
     
    OPEN LoanRemaining_cursor;

    read_loop: LOOP
    	
       	 -- Fetch data from cursor --
        FETCH LoanRemaining_cursor 
        INTO my_trans_date, my_Amount, my_dummy;
        
        SET my_running_bal = my_running_bal + my_Amount;
        
        -- Get Total Remaining Balance --
        
        -- Exit loop if finished --
        IF done THEN
            LEAVE read_loop;
        END IF;
   		-- HAVING DUMMY 0 --
        IF my_dummy = 0 THEN
        	-- Insert Loan Amount --
            INSERT INTO `loanbalance` (memberid, transdate, loan, payment, balance) VALUES (my_memberid, my_trans_date, my_Amount, 0.00, my_running_bal);
        END IF;
        IF my_dummy = 1 THEN
        	-- Insert Payment Transaction --
            INSERT INTO `loanbalance` (memberid, transdate, loan, payment, balance) VALUES (my_memberid, my_trans_date, 0.00, my_Amount, my_running_bal);
        END IF;
    END LOOP read_loop;
    	
    CLOSE LoanRemaining_cursor;
    SELECT * FROM loanbalance;

 END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `memberid` int(11) NOT NULL,
  `membername` varchar(255) NOT NULL,
  `datestarted` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`memberid`, `membername`, `datestarted`) VALUES
(1, 'Gabriel A. Ubas', '2011-01-01');

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE `loan` (
  `transno` int(11) NOT NULL,
  `memberid` int(11) NOT NULL,
  `transdate` date NOT NULL,
  `amount` decimal(13,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `loan`
--

INSERT INTO `loan` (`transno`, `memberid`, `transdate`, `amount`) VALUES
(1, 1, '2000-01-05', '70000.00'),
(2, 1, '2000-02-01', '35000.00'),
(3, 1, '2000-03-05', '55000.00'),
(4, 1, '2000-04-30', '5000.00'),
(5, 1, '2005-08-28', '120000.00');

-- --------------------------------------------------------

--
-- Table structure for table `loanbalance`
--

CREATE TABLE `loanbalance` (
  `memberid` int(11) DEFAULT NULL,
  `transdate` date DEFAULT NULL,
  `loan` decimal(13,2) DEFAULT NULL,
  `payment` decimal(13,2) DEFAULT NULL,
  `balance` decimal(13,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `transno` int(11) NOT NULL,
  `memberid` int(11) NOT NULL,
  `transdate` date NOT NULL,
  `amount` decimal(13,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`transno`, `memberid`, `transdate`, `amount`) VALUES
(1, 1, '2000-01-18', '30000.00'),
(2, 1, '2000-03-14', '33000.00'),
(3, 1, '2000-02-13', '8000.00'),
(4, 1, '2000-04-19', '12000.00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`memberid`);

--
-- Indexes for table `loan`
--
ALTER TABLE `loan`
  ADD PRIMARY KEY (`transno`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`transno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `memberid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `loan`
--
ALTER TABLE `loan`
  MODIFY `transno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `transno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
